import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

/**
 * @Author:Alex_lei
 * @Description:
 */
public class Main {
    public static void main(String[] args) throws  Exception{
        BufferedReader br = new BufferedReader(new FileReader(new File("/Users/alex_lei/Desktop/学校名字")));
        PrintWriter pw = new PrintWriter(new File("/Users/alex_lei/Desktop/c.txt"));
        //存储所有的学校名字
        String az="abcdefghijklmnopqrstuvwxyz";//26个英文字母
        String[] scname = new String[200];
        int ans = 0;
        String stuname="";//学生名字
        String sex="";//学生性别
        String sname=""; //学校名字
        String line = "";
        int num = 0;
        while((line=br.readLine())!=null){
            scname[num++] = line;
        }
        int k=-1;//是否就业
        String sql = "";
        int cnt=0;
        int ks = 0;
        for(int i1=0;i1<az.length();i1++){
            for(int i2=0;i2<az.length();i2++){
                for(int i3=0;i3<az.length();i3++){
                    for(int i4=0;i4<az.length();i4++){
                        k = Math.random()>0.5?1:0;
                        //控制男女
                        if((i1+1)*(i2+1)*(i3+1)*(i4+1)%2==0)
                            sex = "男";
                        else
                            sex = "女";
                        cnt++;
                        if(cnt%3000==0)
                            ks++;
                        sname = scname[ks];
                        stuname=az.substring(i1,i1+1)+az.substring(i2,i2+1)+az.substring(i3,i3+1)+az.substring(i4,i4+1);
                        System.out.println(stuname);
                        sql = "insert into Student values("+(++ans)+","+"\""+stuname+"\""+","+"\""+sex+"\""+","+k+","+"\""+sname+"\""+");";
                        pw.println(sql);
                    }
                }
            }
        }
        pw.close();
        br.close();
    }
}


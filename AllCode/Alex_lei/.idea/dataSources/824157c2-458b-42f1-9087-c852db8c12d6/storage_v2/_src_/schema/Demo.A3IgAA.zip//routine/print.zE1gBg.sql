CREATE PROCEDURE print()
  begin
    select concat('Hello');
end;


CREATE PROCEDURE print1()
  begin
    select concat('Hello');
end;

